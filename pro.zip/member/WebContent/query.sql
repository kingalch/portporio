create TABLE member(
	userid varchar2(10),
	userpwd varchar2(10)

);

SELECT * FROM member;

insert into MEMBER values ('candy', '1234');
insert into MEMBER values ('admin', '5678');

select * from LIB_MEMBER;
